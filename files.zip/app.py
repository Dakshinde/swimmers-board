from flask import Flask, render_template, request, jsonify
import json
import os
from datetime import datetime

app = Flask(__name__)

WORKOUTS_FILE = "workouts.json"
FOOD_LOG_FILE = "food_log.json"


def load_json(filepath):
    if not os.path.exists(filepath):
        return {}
    with open(filepath, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def save_json(filepath, data):
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/today-workout")
def today_workout():
    day = datetime.now().strftime("%A").lower()  # e.g. "monday"
    workouts = load_json(WORKOUTS_FILE)
    workout = workouts.get(day, None)
    return jsonify({"day": day.capitalize(), "workout": workout})


@app.route("/api/import-workout", methods=["POST"])
def import_workout():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON data received"}), 400
        save_json(WORKOUTS_FILE, data)
        return jsonify({"success": True, "message": "Workouts saved successfully"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/log-food", methods=["POST"])
def log_food():
    data = request.get_json()
    entry_text = data.get("entry", "").strip()
    if not entry_text:
        return jsonify({"error": "Empty entry"}), 400

    food_log = load_json(FOOD_LOG_FILE)
    if "entries" not in food_log:
        food_log["entries"] = []

    entry = {
        "text": entry_text,
        "timestamp": datetime.now().isoformat(),
        "date": datetime.now().strftime("%Y-%m-%d"),
    }
    food_log["entries"].append(entry)
    save_json(FOOD_LOG_FILE, food_log)
    return jsonify({"success": True, "entry": entry})


@app.route("/api/food-log")
def get_food_log():
    food_log = load_json(FOOD_LOG_FILE)
    entries = food_log.get("entries", [])
    today = datetime.now().strftime("%Y-%m-%d")
    today_entries = [e for e in entries if e.get("date") == today]
    # Return most recent first
    today_entries = list(reversed(today_entries))
    return jsonify({"entries": today_entries})


@app.route("/api/summary")
def generate_summary():
    # Get today's workout
    day = datetime.now().strftime("%A").lower()
    workouts = load_json(WORKOUTS_FILE)
    workout = workouts.get(day, None)

    # Get today's food
    food_log = load_json(FOOD_LOG_FILE)
    entries = food_log.get("entries", [])
    today = datetime.now().strftime("%Y-%m-%d")
    today_food = [e["text"] for e in entries if e.get("date") == today]

    # Build summary text
    date_str = datetime.now().strftime("%A, %d %B %Y")
    lines = [f"DAILY TRAINING SUMMARY", f"{date_str}", ""]

    lines.append("FOOD:")
    if today_food:
        for item in today_food:
            lines.append(f"  {item}")
    else:
        lines.append("  (no entries logged)")

    lines.append("")
    lines.append("WORKOUT:")
    if workout:
        if isinstance(workout, dict):
            for section, detail in workout.items():
                lines.append(f"  {section.upper()}: {detail}")
        else:
            lines.append(f"  {workout}")
    else:
        lines.append("  (no workout for today)")

    summary = "\n".join(lines)
    return jsonify({"summary": summary})


if __name__ == "__main__":
    # Create empty JSON files if they don't exist
    if not os.path.exists(WORKOUTS_FILE):
        save_json(WORKOUTS_FILE, {})
    if not os.path.exists(FOOD_LOG_FILE):
        save_json(FOOD_LOG_FILE, {"entries": []})

    app.run(debug=True, host="0.0.0.0", port=5000)
