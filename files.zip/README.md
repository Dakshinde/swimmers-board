# Dakshinde Swim Dashboard

A minimal personal web app for tracking swim workouts and food intake.

## Project Structure

```
swim-dashboard/
├── app.py              # Flask backend — all routes and data logic
├── workouts.json       # Weekly workouts (keyed by weekday)
├── food_log.json       # Food entries with timestamps
├── templates/
│   └── index.html      # Single-page UI (HTML + inline JS)
└── static/
    └── style.css       # Mobile-first dark athlete theme
```

## Setup

### 1. Install dependencies

```bash
pip install flask
```

### 2. Run the app

```bash
cd swim-dashboard
python app.py
```

### 3. Open in browser

```
http://localhost:5000
```

For mobile: open `http://<your-laptop-ip>:5000` on your phone (must be on the same WiFi network).

---

## Features

### Today's Workout
- Auto-detects the current weekday
- Displays warmup / main / cooldown sections

### Flashcard Mode
- Compact 4.5 × 10 cm card layout
- White card, black text — easy to read and copy onto water bottle tape

### Import Workouts
- Paste Gemini-generated JSON into the textarea
- Saves to `workouts.json`
- Expected format:
```json
{
  "monday": {
    "warmup": "200m swim",
    "main": "8x50 sprint",
    "cooldown": "100m easy"
  },
  "tuesday": { ... }
}
```

### Food Logger
- Type entries like: `2 eggs milk banana`
- Press Enter or tap `+`
- Saves with timestamp to `food_log.json`
- Shows today's entries below input

### Daily Summary
- Tap **Generate Summary**
- Combines today's food + today's workout
- Copy output directly into Gemini for analysis

---

## Install as App (PWA-style)

On iPhone Safari: Tap Share → "Add to Home Screen"  
On Android Chrome: Tap menu → "Add to Home Screen" / "Install App"

---

## Modifying Workouts Manually

Edit `workouts.json` directly. Keys must be lowercase weekday names:
`monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`
